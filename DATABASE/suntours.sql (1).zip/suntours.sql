-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 26 apr 2022 om 21:00
-- Serverversie: 10.4.14-MariaDB
-- PHP-versie: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `suntours`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `booked`
--

CREATE TABLE `booked` (
  `bookingID` int(11) NOT NULL,
  `packageID` varchar(100) NOT NULL,
  `userID` int(11) NOT NULL,
  `dateID` int(10) NOT NULL,
  `aantalPersonen` int(11) NOT NULL,
  `packageCost` decimal(10,2) NOT NULL,
  `ticketPrice` decimal(10,2) NOT NULL,
  `carAmount` int(10) NOT NULL,
  `carPrice` decimal(10,2) NOT NULL,
  `carDays` int(5) NOT NULL,
  `busTicketAmount` int(10) NOT NULL,
  `busPrice` decimal(10,2) NOT NULL,
  `busDays` int(5) NOT NULL,
  `carBrand` varchar(15) NOT NULL,
  `startingDate` varchar(30) NOT NULL,
  `returnDate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `booked`
--

INSERT INTO `booked` (`bookingID`, `packageID`, `userID`, `dateID`, `aantalPersonen`, `packageCost`, `ticketPrice`, `carAmount`, `carPrice`, `carDays`, `busTicketAmount`, `busPrice`, `busDays`, `carBrand`, `startingDate`, `returnDate`) VALUES
(149, 'Turkije1', 41, 1, 2, '800.00', '0.00', 0, '0.00', 0, 0, '0.00', 0, '0', '2-11-2021', '10-11-2021'),
(154, 'Spanje', 41, 2, 2, '600.00', '0.00', 0, '0.00', 0, 0, '0.00', 0, '0', '16-11-2021', '24-11-2021'),
(157, 'Spanje', 41, 2, 2, '600.00', '0.00', 0, '0.00', 0, 0, '0.00', 0, '0', '16-11-2021', '24-11-2021'),
(158, 'Turkije1', 41, 2, 4, '800.00', '353.00', 2, '207.00', 3, 2, '9.75', 2, 'Opel', '16-11-2021', '24-11-2021'),
(159, 'Turkije1', 41, 2, 4, '800.00', '353.00', 2, '207.00', 3, 2, '9.75', 2, 'Opel', '16-11-2021', '24-11-2021'),
(160, 'Turkije1', 41, 3, 2, '800.00', '0.00', 0, '0.00', 0, 0, '0.00', 0, '0', '7-12-2021', '15-12-2021'),
(161, 'Turkije1', 45, 1, 5, '800.00', '353.00', 0, '0.00', 0, 0, '0.00', 0, '0', '2-11-2021', '10-11-2021'),
(162, 'Turkije1', 45, 1, 5, '800.00', '353.00', 0, '0.00', 0, 0, '0.00', 0, '0', '2-11-2021', '10-11-2021');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `contact`
--

CREATE TABLE `contact` (
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `messageID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `contact`
--

INSERT INTO `contact` (`name`, `email`, `subject`, `message`, `messageID`) VALUES
('naam', 'lucas.hermus@student.gildeopleidingen.nl', 'onderwerp', 'body', 5),
('naam', 'lucas.hermus@student.gildeopleidingen.nl', 'onderwerp', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat aut laudantium commodi tempore ita', 6),
('naam', 'lucas.hermus@student.gildeopleidingen.nl', 'onderwerp', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat aut laudantium commodi tempore itaque voluptates explicabo ipsum nisi blanditiis voluptate! Molestiae, ipsa asperiores odio minus quidem incidunt repudiandae nemo? Quo quis architecto omnis maiores dolore quibusdam perspiciatis excepturi. Rerum aspernatur atque commodi? Eaque pariatur praesentium perspiciatis similique autem alias qui? Reprehenderit minima asperiores quia assumenda adipisci rem quis porro accusamus eaque! Animi vero, sapiente quam id, perferendis commodi deleniti non sequi eveniet aspernatur natus minima tenetur eius impedit pariatur atque quis libero enim, ut expedita corporis? Ea optio sunt saepe aspernatur, ab neque doloribus odio exercitationem ipsa esse. Dolore cupiditate illum provident. Ipsum at eaque dignissimos consequatur magnam cum placeat hic! Nostrum, explicabo! Ipsum a fuga corrupti dolor alias ab modi nobis, placeat corporis cumque magnam eum? Dolorum facere nisi totam possimus eaque volup', 7),
('naam', 'lucas.hermus@student.gildeopleidingen.nl', 'onderwerp', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat aut laudantium commodi tempore itaque voluptates explicabo ipsum nisi blanditiis voluptate! Molestiae, ipsa asperiores odio minus quidem incidunt repudiandae nemo? Quo quis architecto omnis maiores dolore quibusdam perspiciatis excepturi. Rerum aspernatur atque commodi? Eaque pariatur praesentium perspiciatis similique autem alias qui? Reprehenderit minima asperiores quia assumenda adipisci rem quis porro accusamus eaque! Animi vero, sapiente quam id, perferendis commodi deleniti non sequi eveniet aspernatur natus minima tenetur eius impedit pariatur atque quis libero enim, ut expedita corporis? Ea optio sunt saepe aspernatur, ab neque doloribus odio exercitationem ipsa esse. Dolore cupiditate illum provident. Ipsum at eaque dignissimos consequatur magnam cum placeat hic! Nostrum, explicabo! Ipsum a fuga corrupti dolor alias ab modi nobis, placeat corporis cumque magnam eum? Dolorum facere nisi totam possimus eaque volup', 8),
('test69', 'lucas.hermus@student.gildeopleidingen.nl', 'test', 'test', 9),
('test', 'test@test.com', 'test', 'testasdf', 10),
('test', 'test@test.com', 'test', 'testasdf', 11);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `mailinglist`
--

CREATE TABLE `mailinglist` (
  `email` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `emailID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `mailinglist`
--

INSERT INTO `mailinglist` (`email`, `type`, `emailID`) VALUES
('SunTours.devOps@hotmail.com', 'flight', 1),
('SunTours.devOps@hotmail.com', 'flight', 2),
('SunTours.devOps@hotmail.com', 'flight', 3),
('SunTours.devOps@hotmail.com', 'hotel', 4),
('SunTours.devOps@hotmail.com', 'park', 5),
('SunTours.devOps@hotmail.com', 'hotel', 6),
('SunTours.devOps@hotmail.com', 'hotel', 7),
('SunTours.devOps@hotmail.com', 'hotel', 8),
('SunTours.devOps@hotmail.com', 'public transport', 9),
('SunTours.devOps@hotmail.com', 'public transport', 10),
('SunTours.devOps@hotmail.com', 'public transport', 11),
('SunTours.devOps@hotmail.com', 'public transport', 12),
('SunTours.devOps@hotmail.com', 'car rental', 13),
('SunTours.devOps@hotmail.com', 'car rental', 14),
('SunTours.devOps@hotmail.com', 'car rental', 15),
('SunTours.devOps@hotmail.com', 'car rental', 16);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `packages`
--

CREATE TABLE `packages` (
  `packageID` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `stay` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `packages`
--

INSERT INTO `packages` (`packageID`, `price`, `country`, `city`, `stay`) VALUES
('Egypte', 450, 'Luxor', 'Hotel Hilton', 'Marsa Resort'),
('Frankrijk', 950, 'Frankrijk', 'Parijs', 'Village Nature Paris'),
('Spanje', 600, 'Spanje', 'Tenerife', 'Hotel Best'),
('Turkije1', 800, 'Turkije', 'Alanya', 'Gold City Hotel'),
('Turkije2', 500, 'Turkije', 'Kusadasi', 'Hotel Pine Bay Holiday Resort');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `review`
--

CREATE TABLE `review` (
  `packageID` varchar(50) NOT NULL,
  `score` varchar(5) NOT NULL,
  `reviewSubject` varchar(20) NOT NULL,
  `review` varchar(150) NOT NULL,
  `reccomendation` varchar(10) NOT NULL,
  `reviewID` int(11) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `review`
--

INSERT INTO `review` (`packageID`, `score`, `reviewSubject`, `review`, `reccomendation`, `reviewID`, `username`) VALUES
('Spanje', '3', 'sdfsdf', 'dsfsdf', 'ja', 133, 'lucas'),
('Spanje', '3', 'sdfsdfdfg', 'sdf', 'nee', 134, 'lucas'),
('Spanje', '3', 'sdfsdfdfg', 'sdf', 'nee', 135, 'lucas'),
('Spanje', '4', 'asdfdddddd', 'asdf', 'ja', 136, 'test');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `traveldates`
--

CREATE TABLE `traveldates` (
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `startTime` time(6) NOT NULL,
  `endTime` time(6) NOT NULL,
  `dateID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `traveldates`
--

INSERT INTO `traveldates` (`startDate`, `endDate`, `startTime`, `endTime`, `dateID`) VALUES
('2021-11-02', '2021-11-10', '10:45:00.000000', '20:00:00.000000', 1),
('2021-11-16', '2021-11-24', '09:45:00.000000', '15:30:00.000000', 2),
('2021-11-07', '2021-11-15', '19:00:00.000000', '11:00:00.000000', 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `userorder`
--

CREATE TABLE `userorder` (
  `package` varchar(100) NOT NULL,
  `totalPrice` decimal(10,0) NOT NULL,
  `userID` int(10) NOT NULL,
  `orderID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `passwrd` varchar(65) DEFAULT NULL,
  `phoneNumber` varchar(15) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `surName` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `City` varchar(30) NOT NULL,
  `postalcode` varchar(15) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `activationCode` varchar(20) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`userID`, `username`, `email`, `passwrd`, `phoneNumber`, `firstName`, `surName`, `address`, `City`, `postalcode`, `active`, `activationCode`, `deleted`) VALUES
(35, 'test', 'test@test.com', '$2y$10$gbRXg.nRWMTsRBkExWXVS.DzaPg0M0asGbLXnXu48zSSVYgK59/v6', '0123456789', 'test', 'test', 'Jagerstraat 2', '', '6042 KA', 1, '', 0),
(36, 'test2', 'test2@test.com', '$2y$10$.WEv3I04rQNLtSd9WPiv6ecJYcoTKqvXI4E.Ce3S1ed0TP7LcUJhW', '0123456789', 'test', 'test', 'Jagerstraat 2', '', '6042 KA', 1, '', 0),
(41, 'lucas', 'lucas.hermus@student.gildeopleidingen.nl', '$2y$10$6kRw.j6jvSBCC4J1cJ3FHupzDTvqdJZAyE89ar3eHYwpbh8qDRExy', '0123456789', 'test', 'test', 'Jagerstraat 2', 'hamburger', '6042 KA', 1, '5f8578a4', 0),
(42, 'root', 'root2@gmail.com', '$2y$10$Zjs6q/V.gEl2s6rVqv4pL.DhMPhzBi0GHF4yMVu/zFyMKS6llCfIu', '0630108668', 'root', 'rootson', 'rootstraat 9', 'rootStad', '4007 RO', 0, 'b5e7ec26', 0),
(45, 'testguy', 'thomasmaly69@gmail.com', '$2y$10$H.DBBbUXljNXlkuO5ImmVO3zxhkDnWCMm7jGgecK.pmx4NJ6tGW16', '+31630108668', 'Thomas', 'Maly', 'Pastoor Drehmannsstraat', 'Roermond, Herten', '6049 AS', 1, 'ff9bb58b', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vluchten`
--

CREATE TABLE `vluchten` (
  `airline` varchar(30) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `vluchten`
--

INSERT INTO `vluchten` (`airline`, `price`) VALUES
('KLM', '500.00'),
('Rian air', '353.00'),
('Iberia', '467.00');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `booked`
--
ALTER TABLE `booked`
  ADD PRIMARY KEY (`bookingID`);

--
-- Indexen voor tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexen voor tabel `mailinglist`
--
ALTER TABLE `mailinglist`
  ADD PRIMARY KEY (`emailID`);

--
-- Indexen voor tabel `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`reviewID`);

--
-- Indexen voor tabel `traveldates`
--
ALTER TABLE `traveldates`
  ADD PRIMARY KEY (`dateID`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `booked`
--
ALTER TABLE `booked`
  MODIFY `bookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT voor een tabel `contact`
--
ALTER TABLE `contact`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT voor een tabel `mailinglist`
--
ALTER TABLE `mailinglist`
  MODIFY `emailID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT voor een tabel `review`
--
ALTER TABLE `review`
  MODIFY `reviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT voor een tabel `traveldates`
--
ALTER TABLE `traveldates`
  MODIFY `dateID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
